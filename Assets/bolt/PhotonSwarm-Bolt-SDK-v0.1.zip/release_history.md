Bolt PhotonSquad SDK release history
=======================================

### Version 0.1 (12.08.2015 - commit 5d836d65bac089dd4454dc681310a5c346f69573)
    - ADDED: Bolt PhotonSquad SDK
