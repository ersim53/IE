﻿
using System;
using System.Collections.Generic;
using System.Linq;
using ExitGames.Client.Photon;
using UnityEngine;
using ExitGames.Client.Photon.LoadBalancing;

public class PhotonLBClientSettings
{
    public const string MasterServerAddress = "127.0.0.1:5055";
}

