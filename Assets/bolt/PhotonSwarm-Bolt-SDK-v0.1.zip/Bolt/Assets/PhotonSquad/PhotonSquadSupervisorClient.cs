﻿using UnityEngine;
using System.Collections;
using System.IO.Pipes;
using System.Threading;

public class PhotonSquadSupervisorClient : MonoBehaviour {

    NamedPipeClientStream pipeClient;
    static PhotonSquadSupervisorClient instance;
    const string logPrefix = "[PhotonSquadSupervisorClient] ";

	void Start () 
    {
	
	}
	
	void Update () 
    {
	}

    static public bool Init(string[] args)
    {
        Debug.Log(logPrefix + "Init");
        int pipeArg = System.Array.IndexOf(args, "-pipe");
        string pipeName;
        if (pipeArg < 0 || pipeArg + 1 >= args.Length)
        {
            Debug.LogError(logPrefix + "-pipe command line argument missing");
            return false;
        }
        pipeName = args[pipeArg + 1];
        var objs = GameObject.FindObjectsOfType(typeof(PhotonSquadSupervisorClient));
        if (objs.Length > 0)
        {
            Debug.LogError(logPrefix + "Already initialized");
            return false;
        }
        
        GameObject go = new GameObject();
        instance = (PhotonSquadSupervisorClient)go.AddComponent<PhotonSquadSupervisorClient>();
        go.name = "PhotonSquadSupervisorClient";
        go.hideFlags = HideFlags.HideInHierarchy;
        DontDestroyOnLoad(go);
        var pipeClientThread = new Thread(PipeClientThread);
        pipeClientThread.Name = "PipeClientThread";
        pipeClientThread.Start(pipeName);
        return true;
    }

    static string pipeNameReader(string pipeName)
    {
        return pipeName + "-";
    }

    static string pipeNameWriter(string pipeName)
    {
        return pipeName;
    }

    private static void PipeClientThread(object data)
    {
        var pipeName = (string)data;
        var pipeClientWriter = new NamedPipeClientStream(".", pipeNameWriter(pipeName), PipeDirection.Out, PipeOptions.None);
        var pipeClientReader = new NamedPipeClientStream(".", pipeNameReader(pipeName), PipeDirection.In, PipeOptions.None);
        Debug.Log(logPrefix + "Connecting pipe writer " + pipeNameWriter(pipeName) + "...");
        pipeClientWriter.Connect();
        Debug.Log(logPrefix + "Connecting pipe reader " + pipeNameReader(pipeName) + "...");
        pipeClientReader.Connect();
        
        var writer = new Photon.Hive.Plugin.PhotonSquad.StreamString(pipeClientWriter);
        var reader = new Photon.Hive.Plugin.PhotonSquad.StreamString(pipeClientReader);

        while (true)
        {
            var line = reader.ReadString();
            Debug.Log(logPrefix + "Pipe input: " + line);
            if (line == "exit")
            {
                Debug.Log(logPrefix + "Got exit command");
//                writer.WriteString("exit_ack");
                pipeClientWriter.Close();
                pipeClientReader.Close();
                Application.Quit();
                return;
            }
            else if (line == "ping")
            {
                writer.WriteString("pong");
            }
            else
            {
                writer.WriteString("");
            }
            Thread.Sleep(10);
        }                
    }
}
