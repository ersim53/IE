﻿using UnityEngine;
using System.Collections;
using ExitGames.Client.Photon.LoadBalancing;

public class PhotonLBClientGUI : MonoBehaviour
{

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    void OnGUI()
    {
        GUILayout.Label("State: " + PhotonLBClient.Client.State + " " + (PhotonLBClient.Client.State == ClientState.Joined ? (PhotonLBClient.Client.CurrentRoom.Name + "/" + PhotonLBClient.Client.CurrentRoom.PlayerCount) : ""));
        if (PhotonLBClient.Client.State == ClientState.Joined)
        {
            foreach (var x in PhotonLBClient.Client.CurrentRoom.CustomProperties)
            {
                GUILayout.Label("prop: " + x.Key + " = " + x.Value);
            }
        }
        switch (PhotonLBClient.Client.State)
        {
            case ClientState.Disconnected:
            case ClientState.Uninitialized:
                if (GUILayout.Button("Connect To Photon Server"))
                {
                    PhotonLBClient.Client.MasterServerAddress = PhotonLBClientSettings.MasterServerAddress;
                    PhotonLBClient.Client.Connect();
                }
                break;
            case ClientState.Joined:
                if (GUILayout.Button("Leave Room"))
                {
                    PhotonLBClient.Client.OpLeaveRoom();
                }
                break;
            case ClientState.JoinedLobby:
                if (GUILayout.Button("Join Random Room"))
                {
                    PhotonLBClient.Client.OpJoinRandomRoom(null, 0);
                }
                GUILayout.BeginHorizontal();
                GUILayout.Label("room:");
                roomName = GUILayout.TextField(roomName);
                GUILayout.EndHorizontal();
                GUILayout.BeginHorizontal();
                GUILayout.Label("map:");
                map = GUILayout.TextField(map);
                GUILayout.EndHorizontal();
                if (GUILayout.Button("Create Room"))
                {
                    PhotonLBClient.Client.OpCreateRoom(roomName, new RoomOptions() { CustomRoomProperties = new ExitGames.Client.Photon.Hashtable() { { "map", map }, { "level", 10 } }, MaxPlayers = 10 }, null);
                }

                GUILayout.BeginHorizontal();
                GUILayout.Label("Join: " );
                foreach (var r in PhotonLBClient.Client.RoomInfoList)
                {
                    if (GUILayout.Button(r.Key))
                    {
                        PhotonLBClient.Client.OpJoinRoom(r.Key);
                    }
                }
                GUILayout.EndHorizontal();
                break;
        }
        if (GUILayout.Button("Disconnect"))
        {
            PhotonLBClient.Client.Disconnect();
        }
    }
    string  roomName = "room1";
    string map = "Level1";
}
