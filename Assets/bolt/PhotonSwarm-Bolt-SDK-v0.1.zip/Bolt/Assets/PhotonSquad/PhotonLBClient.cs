﻿
using System;
using System.Collections.Generic;
using System.Linq;
using ExitGames.Client.Photon;
using UnityEngine;
using ExitGames.Client.Photon.LoadBalancing;

public class PhotonLBClient : MonoBehaviour
{
    const string RoomPropServer = "_server";
    internal const string logPrefix = "[PhotonLBClient] ";

    private static PhotonLBClient instance;

    internal BoltLBClient client;

    /// <summary>Returns underlying Photon Voice client.</summary>
    public static LoadBalancingClient Client { get { return instance.client; } }

    void Awake()
    {
        client = new BoltLBClient();
        client.OnStateChangeAction = OnStateChangeAction;
        client.OnEventAction = OnEventAction;
        client.OnOpResponseAction = OnOpResponseAction;
        instance = this;
    }

    protected void Update()
    {
        client.Service();
    }

    protected void OnApplicationQuit()
    {
        client.Disconnect();
    }

    static public bool Init(string[] args)
    {
        Debug.Log(logPrefix + "Init");

        GameObject go = new GameObject();
        instance = (PhotonLBClient)go.AddComponent<PhotonLBClient>();
        go.name = "PhotonLBClient";
        go.hideFlags = HideFlags.HideInHierarchy;
        DontDestroyOnLoad(go);
        return true;
    }
    static public string BoltServerAddress { get { return instance.boltServerAddress; } }
    private string boltServerAddress;

    private void checkRoomProps()
    {
        if (client.State == ClientState.Joined)
        {
            var props = client.CurrentRoom.CustomProperties;
            if (props.ContainsKey(RoomPropServer))
            {
                boltServerAddress = (string)props[RoomPropServer];
                Debug.Log(logPrefix + "Got Bolt Server address " + boltServerAddress + ". Staring Bolt client...");

                BoltLauncher.StartClient();
            }
        }
    }

	// room properties checked on every OnStateChangeAction, OnStateChangeAction and OnOpResponseAction to workaround loadbalancing api wrong state or properties bug in OnStateChangeAction when Joined and possible other similar bugs
    private void OnStateChangeAction(ClientState s)
    {
        Debug.Log(logPrefix + "OnStateChangeAction: " + s);        
        //switch (s)
        //{
        //    case ClientState.Joined:
        //        checkRoomProps();
        //        break;
        //}
        checkRoomProps();
    }

    private void OnEventAction(EventData ev)
    {
        Debug.Log(logPrefix + "OnEventAction: " + ev.Code);
        //switch (ev.Code)
        //{
        //    case EventCode.PropertiesChanged:
        //        checkRoomProps();
        //        break;
        //}
        checkRoomProps();
    }

    private void OnOpResponseAction(OperationResponse resp)
    {
        Debug.Log(logPrefix + "OnOpResponseAction: " + resp.OperationCode);
        checkRoomProps();
    }
}

internal class BoltLBClient : LoadBalancingClient
{
    public override void DebugReturn(DebugLevel level, string message)
    {
        if (level == DebugLevel.ERROR)
        {
            Debug.LogError(PhotonLBClient.logPrefix + message);
        }
        else if (level == DebugLevel.WARNING)
        {
            Debug.LogWarning(PhotonLBClient.logPrefix + message);
        }
        else if (level == DebugLevel.INFO)
        {
            Debug.Log(PhotonLBClient.logPrefix + message);
        }
        else if (level == DebugLevel.ALL)
        {
            Debug.Log(PhotonLBClient.logPrefix + message);
        }
    }
}