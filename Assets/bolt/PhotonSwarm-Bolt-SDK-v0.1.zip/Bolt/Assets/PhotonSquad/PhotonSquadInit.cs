﻿using UnityEngine;
using System.Collections;
using System;

public class PhotonSquadInit : BoltInternal.GlobalEventListenerBase
{
    const string logPrefix = "[PhotonSquadInit] ";
    void Start()
    {
        Debug.Log(logPrefix + "App started");
        string[] args = System.Environment.GetCommandLineArgs();

        if (System.Array.IndexOf(args, "-batchmode") >= 0) // server
        {
            Debug.Log(logPrefix + "Initializing server");
            Bolt.ConsoleWriter.Open();

            Debug.Log(logPrefix + "Batch mode");
            int portArg = System.Array.IndexOf(args, "-port");

            if (portArg >= 0 && args.Length > portArg + 1)
            {
                Debug.Log(logPrefix + "Starting Bolt Server");
                BoltConfig config = BoltRuntimeSettings.instance.GetConfigCopy();
                BoltLauncher.StartServer(new UdpKit.UdpEndPoint(new UdpKit.UdpIPv4Address(0), ushort.Parse(args[portArg + 1])), config);
            }

            int mapArg = System.Array.IndexOf(args, "-map");

            if (mapArg >= 0)
            {
                map = args[mapArg + 1];
            }

            if (!PhotonSquadSupervisorClient.Init(args))
            {
                Debug.LogError(logPrefix + "PhotonSquadSupervisorClient initialization error");
                Application.Quit();
            }
        }
        else //client
        {
            Debug.Log(logPrefix + "Initializing client");
            if (!PhotonLBClient.Init(args))
            {
                Debug.LogError(logPrefix + "PhotonLBClient initialization error");
                Application.Quit();
            }
        }
    }

    string map;
    public override void BoltStartDone()
    {
        Debug.Log(logPrefix + "BoltStartDone");
        if (BoltNetwork.isServer)
        {
            Debug.Log(logPrefix + "Loading scene " + map);
            BoltNetwork.LoadScene(map);
        }
        else
        {
            Debug.Log(logPrefix + "Connecting Bolt client to " + PhotonLBClient.BoltServerAddress);
            BoltNetwork.Connect(UdpKit.UdpEndPoint.Parse(PhotonLBClient.BoltServerAddress));
        }
    }
    
}