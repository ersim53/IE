Bolt PhotonSquad SDK
=======================================

PhotonSquad plugin for Photon Server starts Bolt server instance each time new Photon room created and stops it after room destroyed. 
Plugin controls started server instance via named pipes.


## Package Content

### PhotonServer folder
Photon Server binary distribution with PhotonSquad plugin added.


### Bolt folder
Unity Bolt sample project with components required for PhotonSquad operations added:

- Bolt\Assets\PhotonLoadbalancingApi and Bolt\Assets\Plugins - standard Photon Loadbalancing Api (part of Photon-Unity3D-Sdk)
- Bolt\Assets\PhotonSquad : Unity scripts running Photon Server client in Unity scene


## Setup Photon Server with PhotonSquad plugin
1. Optionally edit Photon Server configuration file PhotonServer\deploy\bin_Win32\PhotonServer.config (see https://doc.photonengine.com/en/onpremise/current/getting-started/server-config)
2. Edit PluginSettings/Plugins/Plugin section of PhotonSquad plugin configuration file PhotonServer\deploy\LoadBalancing\GameServer\bin\Photon.LoadBalancing.dll.config:
 - ServerPath: path to Bolt application executable
 - ServerArgs: Bolt server executable command line arguments. When read, {...} tags replaced with:
 - - {port}: Bolt server port (game clients connect to) automatically assigned by PhotonSquad plugin
 - - {pipe}: pipe name automatically assigned by PhotonSquad plugin for communication between Bolt server and plugin
 - - {maxplayers}: max players property of Photon room
 - - {{name}}: value of Photon custom room property matching specified 'name'
 - - {props} ... {/props}: text between tags repeated for every custom room property not mentioned in {{...}} tags, {propname} and {propvalue} replaced with property name and value
 - ServerHost: Bolt server ip address for game client connections (sent to clients along with automatically assigned port)
 - ServerPorts: ports available for Bolt servers to listen for game client connections: comma separated list of ports and port ranges("7777-7787,7800"). Total count of ports defines maximum number of server instances running simultaneously allowed
 - ServerStartTimeoutMs: kill Bolt server process after specified milliseconds passed since start if no response to ping received from server
 - ServerPingTimeoutMs: kill Bolt server process after specified milliseconds passed since last response to ping
 - ServerStopTimeoutMs: kill Bolt server process after specified milliseconds passed since "exit" command sent to the server if server process is still running

## Build Bolt executable (server and client)
1. Open Bolt project in Unity editor.
2. Open Bolt\Assets\PhotonSquad\PhotonLBClientSettings.cs in text editor and set 'MasterServerAddress' constant to the address Photon Master Server UDP peer listens on (see PhotonServer\deploy\bin_Win32\PhotonServer.config)
3. Build standalone application with both MainMenu and Level1 scenes (Bolt\Assets\bolt\sample\bolt_sample\scenes). 
Make sure that resulting executable path is the same as in ServerPath entry of PhotonSquad plugin configuration (e.g. Bolt\Deploy\sample.exe).
Same executable used as Bolt server and as standalone client depending on command line parameters.
4. If you'd like to run Bolt client from editor, open MainMenu scene in editor.

## Start Photon Server with PhotonSquad plugin
1. In PhotonServer\deploy\bin_Win32\ folder, run command: \> PhotonSocketServer.exe /run LoadBalancing
2. Check PhotonServer\deploy\bin_Win32\log\Photon-LoadBalancing-...log for errors preventing Photon Server from start (e.g. config reading error).
If Photon Server started, PhotonSocketServer.exe should be in processes list.
3. To stop Photon Server, run command: \> taskkill /f /im PhotonSocketServer.exe

## Start Bolt clients
1. Start standalone or in-editor client.
2. Press 'Connect to Photon Server' button.
3. After client state has changed to JoinedLobby (topmost label in ui), press 'Create Room'.
4. Bolt server instance should be started by PhotonSquad plugin (black console window appears per server instance) and Bolt client connects to that instance immediately.
5. On other clients, press button with room name next to "Join:" label when client is in JoinedLobby state.
6. Play Bolt sample game. 
7. As soon as last client leaves Photon room (via closing client instance e.g.), Bolt server instance shuts down as commanded by PhotonSquad plugin.
8. Check PhotonServer\deploy\log\GSGame.log for errors and info on rooms and Bolt servers creation, execution and closing.
9. Each time new room created, plugin rereads PhotonServer\deploy\LoadBalancing\GameServer\bin\Photon.LoadBalancing.dll.config. 
Room restart is enough for PhotonSquad plugin configuration changes take effect.